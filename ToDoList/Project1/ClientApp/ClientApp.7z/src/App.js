import React from 'react';
import './styles/App.css';
import TaskList from './components/TaskList';
import MyButton from './components/MyButton/MyButton';
import TaskForm from './components/TaskForm';



class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tasks: [],
            current: 0,
            isformvisible: false,
        };
    }
    loadTasks = async () => {
        fetch("weatherforecast")
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        tasks: result,
                    });
                },
                (error) => {
                    console.log(error);
                }
            )
    };

    createTask = (newTaskData) => {
        fetch('weatherforecast', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify(newTaskData)
           
        })
            .then((response) => {
                this.loadTasks();
            })
            .catch(error => {
                console.log(error)
            })
            
    }

    
    shownewform = () => {

        this.setState({ isformvisible: true });
    }

    changeTaskData = (newData) => {
        fetch('weatherforecast', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify(newData)

        })
            .catch(error => {
                console.log(error)
            })
        this.loadTasks();
    }

    removeTask = (task) => {
        
        fetch('weatherforecast', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify(task)

        })
            .then((response) => {
                this.loadTasks();
            })
            .catch(error => {
                console.log(error)
            })
    }

    componentDidMount() {
        this.loadTasks();
      }

    render() {
        return (
            <div className="App">
                <TaskList
                    shownewform={this.shownewform}
                    opentask={(task) => {
                        console.log(task)}}
                    tasks={this.state.tasks} />
                {this.state.isformvisible && <TaskForm create={this.createTask} />}
            </div>
        );
    }
}

export default App;

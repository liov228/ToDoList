import React from 'react';
import MyButton from './MyButton/MyButton';
import TaskItem from './TaskItem';

const TaskList = ({ opentask, shownewform, tasks, title }) => {
    return(
        <div className="tasklist">
        <h1 style={{textAlign:'center'}}>
        {title}
        </h1>
      {tasks.map((task,index)=>
          <TaskItem opentask={() => {opentask(task)}} number={index+1} task={task} key={task.id}/>
      )
            }
            <MyButton onClick={shownewform}>add</MyButton>
    </div>
    );
};
export default TaskList;
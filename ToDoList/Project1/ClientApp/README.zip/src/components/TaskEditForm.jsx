import React,{useState} from 'react';
import MyButton from './MyButton/MyButton';
import MyInput from './input/MyInput';

const TaskForm = ({ edited}) => {
    const [task, setTask] = useState({ title: edited.title, body: edited.body })
    

    return(
<form>
        <MyInput
        value={edited.title}
        onChange={e=>setTask({...task,title:e.target.value})}
        type='text' 
        placeholder='создать задачу'
        />
        <MyInput
                value={edited.body}
                onChange={e => setTask({ ...task, body: e.body.value })}
        type="text" 
        placeholder="описание"
        />
        {/*<MyButton onClick={addNewTask}>Создать задачу</MyButton>*/}
        </form>)    
}      
export default TaskForm;